/**
 * Course: CS341 Data Structures
 * Date: April 2018
 * Assignment: CS341_FinalProject
 * Authors: Trevor Conway, Tristin Harvell, Travis Kruse, Johnny Tran
 */
package FramePackage;

import GamePackage.Blackjack;
import MainPackage.Card;
import MainPackage.Menu;
import java.util.*;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;
import sun.applet.Main;

public class bjFrame extends javax.swing.JFrame {

    /**
     * Creates new form bjFrame
     */
    public bjFrame() {
        initComponents();
    }

    Blackjack bjGame = new Blackjack();
    int playerCount = 0;

    List<Card> houseHand = new ArrayList<Card>();
    List<Card> oneHand = new ArrayList<Card>();
    List<Card> twoHand = new ArrayList<Card>();

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        onePanel = new javax.swing.JPanel();
        oneLabel = new javax.swing.JLabel();
        one1Label = new javax.swing.JLabel();
        one3Label = new javax.swing.JLabel();
        one4Label = new javax.swing.JLabel();
        one5Label = new javax.swing.JLabel();
        one2Label = new javax.swing.JLabel();
        oneStandButton = new javax.swing.JButton();
        oneHitButton = new javax.swing.JButton();
        oneSumLabel = new javax.swing.JLabel();
        oneSumField = new javax.swing.JLabel();
        twoPanel = new javax.swing.JPanel();
        twoLabel = new javax.swing.JLabel();
        two1Label = new javax.swing.JLabel();
        two2Label = new javax.swing.JLabel();
        two3Label = new javax.swing.JLabel();
        two4Label = new javax.swing.JLabel();
        two5Label = new javax.swing.JLabel();
        twoStandButton = new javax.swing.JButton();
        twoHitButton = new javax.swing.JButton();
        twoSumLabel = new javax.swing.JLabel();
        twoSumField = new javax.swing.JLabel();
        onButton = new javax.swing.JButton();
        offButton = new javax.swing.JButton();
        housePanel = new javax.swing.JPanel();
        houseLabel = new javax.swing.JLabel();
        house1Label = new javax.swing.JLabel();
        house2Label = new javax.swing.JLabel();
        house3Label = new javax.swing.JLabel();
        house4Label = new javax.swing.JLabel();
        house5Label = new javax.swing.JLabel();
        dealButton = new javax.swing.JButton();
        checkWinnerButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        houseSumField = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Blackjack");

        onePanel.setBackground(new java.awt.Color(0, 102, 0));

        oneLabel.setFont(new java.awt.Font("MingLiU-ExtB", 1, 24)); // NOI18N
        oneLabel.setForeground(new java.awt.Color(255, 255, 255));
        oneLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        oneLabel.setText("Hand One");

        one1Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        one3Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        one4Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        one5Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        one2Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        oneStandButton.setBackground(new java.awt.Color(51, 255, 51));
        oneStandButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        oneStandButton.setText("Stand");
        oneStandButton.setEnabled(false);
        oneStandButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oneStandButtonActionPerformed(evt);
            }
        });

        oneHitButton.setBackground(new java.awt.Color(51, 255, 51));
        oneHitButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        oneHitButton.setText("Hit");
        oneHitButton.setEnabled(false);
        oneHitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oneHitButtonActionPerformed(evt);
            }
        });

        oneSumLabel.setFont(new java.awt.Font("MingLiU-ExtB", 3, 13)); // NOI18N
        oneSumLabel.setForeground(new java.awt.Color(255, 255, 255));
        oneSumLabel.setText("Sum: ");

        oneSumField.setFont(new java.awt.Font("MingLiU-ExtB", 1, 18)); // NOI18N
        oneSumField.setForeground(new java.awt.Color(255, 255, 255));
        oneSumField.setText("<Sum>");

        javax.swing.GroupLayout onePanelLayout = new javax.swing.GroupLayout(onePanel);
        onePanel.setLayout(onePanelLayout);
        onePanelLayout.setHorizontalGroup(
            onePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(onePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(oneLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(oneSumLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oneSumField, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(onePanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(one1Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(one2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(one3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(one4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(one5Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(onePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(oneHitButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneStandButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        onePanelLayout.setVerticalGroup(
            onePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(onePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(onePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oneSumLabel)
                    .addComponent(oneSumField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(onePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(one4Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addComponent(one3Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addComponent(one2Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, onePanelLayout.createSequentialGroup()
                        .addComponent(oneHitButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(oneStandButton))
                    .addComponent(one1Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addComponent(one5Label, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE))
                .addContainerGap())
        );

        twoPanel.setBackground(new java.awt.Color(0, 102, 0));

        twoLabel.setFont(new java.awt.Font("MingLiU-ExtB", 1, 24)); // NOI18N
        twoLabel.setForeground(new java.awt.Color(255, 255, 255));
        twoLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        twoLabel.setText("Hand Two");

        two1Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        two2Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        two3Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        two4Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        two5Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        twoStandButton.setBackground(new java.awt.Color(51, 255, 51));
        twoStandButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        twoStandButton.setText("Stand");
        twoStandButton.setEnabled(false);
        twoStandButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                twoStandButtonActionPerformed(evt);
            }
        });

        twoHitButton.setBackground(new java.awt.Color(51, 255, 51));
        twoHitButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        twoHitButton.setText("Hit");
        twoHitButton.setEnabled(false);
        twoHitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                twoHitButtonActionPerformed(evt);
            }
        });

        twoSumLabel.setFont(new java.awt.Font("MingLiU-ExtB", 3, 13)); // NOI18N
        twoSumLabel.setForeground(new java.awt.Color(255, 255, 255));
        twoSumLabel.setText("Sum: ");

        twoSumField.setFont(new java.awt.Font("MingLiU-ExtB", 1, 18)); // NOI18N
        twoSumField.setForeground(new java.awt.Color(255, 255, 255));
        twoSumField.setText("<Sum>");

        onButton.setBackground(new java.awt.Color(51, 255, 51));
        onButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        onButton.setText("On");
        onButton.setToolTipText("");
        onButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onButtonActionPerformed(evt);
            }
        });

        offButton.setBackground(new java.awt.Color(51, 255, 51));
        offButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        offButton.setText("Off");
        offButton.setToolTipText("");
        offButton.setEnabled(false);
        offButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                offButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout twoPanelLayout = new javax.swing.GroupLayout(twoPanel);
        twoPanel.setLayout(twoPanelLayout);
        twoPanelLayout.setHorizontalGroup(
            twoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(twoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(twoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(twoPanelLayout.createSequentialGroup()
                        .addComponent(twoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(twoSumLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(twoSumField, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(twoPanelLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(two1Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(two2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(two3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(two4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(two5Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(twoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(twoHitButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(twoPanelLayout.createSequentialGroup()
                                .addComponent(onButton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(offButton, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(twoStandButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        twoPanelLayout.setVerticalGroup(
            twoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(twoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(twoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(twoLabel)
                    .addComponent(twoSumLabel)
                    .addComponent(twoSumField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(twoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(two4Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addComponent(two3Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addComponent(two2Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, twoPanelLayout.createSequentialGroup()
                        .addGroup(twoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(onButton)
                            .addComponent(offButton))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(twoHitButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(twoStandButton))
                    .addComponent(two1Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                    .addComponent(two5Label, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE))
                .addContainerGap())
        );

        housePanel.setBackground(new java.awt.Color(0, 102, 0));

        houseLabel.setFont(new java.awt.Font("MingLiU-ExtB", 1, 24)); // NOI18N
        houseLabel.setForeground(new java.awt.Color(255, 255, 255));
        houseLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        houseLabel.setText("House Hand");

        house1Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        house2Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        house3Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        house4Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        house5Label.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(204, 204, 0)));

        dealButton.setBackground(new java.awt.Color(51, 255, 51));
        dealButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        dealButton.setText("Deal");
        dealButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealButtonActionPerformed(evt);
            }
        });

        checkWinnerButton.setBackground(new java.awt.Color(51, 255, 51));
        checkWinnerButton.setFont(new java.awt.Font("MingLiU-ExtB", 3, 14)); // NOI18N
        checkWinnerButton.setText("Check Winner");
        checkWinnerButton.setEnabled(false);
        checkWinnerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkWinnerButtonActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("MingLiU-ExtB", 3, 13)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Sum:");

        houseSumField.setFont(new java.awt.Font("MingLiU-ExtB", 1, 18)); // NOI18N
        houseSumField.setForeground(new java.awt.Color(255, 255, 255));
        houseSumField.setText("<Sum>");

        javax.swing.GroupLayout housePanelLayout = new javax.swing.GroupLayout(housePanel);
        housePanel.setLayout(housePanelLayout);
        housePanelLayout.setHorizontalGroup(
            housePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(housePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(houseLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(houseSumField, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(housePanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(house1Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(house2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(house3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(house4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(house5Label, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(housePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(checkWinnerButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dealButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        housePanelLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {house1Label, house2Label, house3Label, house4Label, house5Label});

        housePanelLayout.setVerticalGroup(
            housePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(housePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(housePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(houseLabel)
                    .addComponent(jLabel1)
                    .addComponent(houseSumField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(housePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, housePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(house3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(housePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, housePanelLayout.createSequentialGroup()
                                .addComponent(dealButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(checkWinnerButton))
                            .addComponent(house2Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                            .addComponent(house1Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE))
                        .addComponent(house4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(house5Label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(twoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(housePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(onePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(housePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(onePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(twoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void dealButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealButtonActionPerformed
        // TODO add your handling code here:
        bjGame = new Blackjack();

        oneHitButton.setEnabled(true);
        oneStandButton.setEnabled(true);
        dealButton.setEnabled(false);

        houseHand.clear();
        oneHand.clear();
        twoHand.clear();

        houseSumField.setText("<Sum>");

        if (playerCount == 0) {
            twoSumField.setText("<Sum>");
        }

        try {
            one1Label.setIcon(null);
            one2Label.setIcon(null);
            one3Label.setIcon(null);
            one4Label.setIcon(null);
            one5Label.setIcon(null);

            two1Label.setIcon(null);
            two2Label.setIcon(null);
            two3Label.setIcon(null);
            two4Label.setIcon(null);
            two5Label.setIcon(null);

            house1Label.setIcon(null);
            house2Label.setIcon(null);
            house3Label.setIcon(null);
            house4Label.setIcon(null);
            house5Label.setIcon(null);

        } catch (Exception e) {
        }

        houseHand = bjGame.generateHand();
        oneHand = bjGame.generateHand();

        if (playerCount == 1) {
            twoHand = bjGame.generateHand();
        }
        oneSumField.setText("" + bjGame.getSum(oneHand));
        if (playerCount == 1) {
            twoSumField.setText("" + bjGame.getSum(twoHand));
        }

        one1Label.setIcon(oneHand.get(0).getCardImage());
        one2Label.setIcon(oneHand.get(1).getCardImage());

        if (playerCount == 1) {
            two1Label.setIcon(twoHand.get(0).getCardImage());
        }
        if (playerCount == 1) {
            two2Label.setIcon(twoHand.get(1).getCardImage());
        }

        house1Label.setIcon(houseHand.get(0).getCardImage());
        ImageIcon image = new ImageIcon(getClass().getResource("/cards/red_back.jpg"));
        house2Label.setIcon(image);

        onButton.setEnabled(false);
        offButton.setEnabled(false);

    }//GEN-LAST:event_dealButtonActionPerformed

    private void checkWinnerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkWinnerButtonActionPerformed
        // TODO add your handling code here:
        while (bjGame.getSum(houseHand) <= 17) {
            houseHand.add(bjGame.hit());
        }
        try {
            house2Label.setIcon(houseHand.get(1).getCardImage());
            house3Label.setIcon(houseHand.get(2).getCardImage());
            house4Label.setIcon(houseHand.get(3).getCardImage());
            house5Label.setIcon(houseHand.get(4).getCardImage());
        } catch (Exception e) {
        }
        houseSumField.setText("" + bjGame.getSum(houseHand));

        //stats only apply to the first hand
        switch (bjGame.checkWinner(oneHand, houseHand)) {
            case 1:
                oneSumField.setText("WINNER: " + bjGame.getSum(oneHand));
                int bjWinsTemp = Menu.player.getBjWins();
                bjWinsTemp++;
                Menu.player.setBjWins(bjWinsTemp);
                break;
            case 0:
                oneSumField.setText("TIE: " + bjGame.getSum(oneHand));
                break;
            case -1:
                oneSumField.setText("LOSER: " + bjGame.getSum(oneHand));
                int bjLossesTemp = Menu.player.getBjLosses();
                bjLossesTemp++;
                Menu.player.setBjLosses(bjLossesTemp);
                break;
            default:
                oneSumField.setText("BROKE: " + bjGame.getSum(oneHand));
                break;
        }
        if (playerCount == 1) {
            switch (bjGame.checkWinner(twoHand, houseHand)) {
                case 1:
                    twoSumField.setText("WINNER: " + bjGame.getSum(twoHand));
                    int bjWinsTemp = Menu.player.getBjWins();
                    bjWinsTemp++;
                    Menu.player.setBjWins(bjWinsTemp);
                    break;
                case 0:
                    twoSumField.setText("TIE: " + bjGame.getSum(twoHand));
                    break;
                case -1:
                    int bjLossesTemp = Menu.player.getBjLosses();
                    bjLossesTemp++;
                    Menu.player.setBjLosses(bjLossesTemp);
                    twoSumField.setText("LOSER: " + bjGame.getSum(twoHand));
                    break;
                default:
                    twoSumField.setText("BROKE: " + bjGame.getSum(twoHand));
                    break;
            }
        }

        if ((bjGame.checkWinner(oneHand, houseHand) == 1) || (bjGame.checkWinner(twoHand, houseHand) == 1)) {
            playSound("/AudioPackage/win.wav");
        }

        if (playerCount == 1) {
            offButton.setEnabled(true);
        } else {
            onButton.setEnabled(true);
        }
        checkWinnerButton.setEnabled(false);
        dealButton.setEnabled(true);
    }//GEN-LAST:event_checkWinnerButtonActionPerformed

    private void oneHitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oneHitButtonActionPerformed
        // TODO add your handling code here:
        oneHand.add(bjGame.hit());
        try {
            one3Label.setIcon(oneHand.get(2).getCardImage());
            one4Label.setIcon(oneHand.get(3).getCardImage());
            one5Label.setIcon(oneHand.get(4).getCardImage());
        } catch (Exception e) {
        }
        if (bjGame.getSum(oneHand) > 21) {
            oneHitButton.setEnabled(false);
            oneSumField.setText("BUST: " + bjGame.getSum(oneHand));
        } else {
            oneSumField.setText("" + bjGame.getSum(oneHand));
        }
    }//GEN-LAST:event_oneHitButtonActionPerformed

    private void oneStandButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oneStandButtonActionPerformed
        // TODO add your handling code here:
        if (playerCount == 1) {
            twoHitButton.setEnabled(true);
            twoStandButton.setEnabled(true);
        } else if (playerCount == 0) {
            checkWinnerButton.setEnabled(true);
        }
        oneStandButton.setEnabled(false);
        oneHitButton.setEnabled(false);
    }//GEN-LAST:event_oneStandButtonActionPerformed

    private void twoHitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_twoHitButtonActionPerformed
        // TODO add your handling code here:
        twoHand.add(bjGame.hit());
        try {
            two3Label.setIcon(twoHand.get(2).getCardImage());
            two4Label.setIcon(twoHand.get(3).getCardImage());
            two5Label.setIcon(twoHand.get(4).getCardImage());
        } catch (Exception e) {
        }
        if (bjGame.getSum(twoHand) > 21) {
            twoHitButton.setEnabled(false);
            twoSumField.setText("BUST: " + bjGame.getSum(twoHand));
        } else {

            twoSumField.setText("" + bjGame.getSum(twoHand));
        }
    }//GEN-LAST:event_twoHitButtonActionPerformed

    private void twoStandButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_twoStandButtonActionPerformed
        // TODO add your handling code here:
        twoHitButton.setEnabled(false);
        twoStandButton.setEnabled(false);
        checkWinnerButton.setEnabled(true);

    }//GEN-LAST:event_twoStandButtonActionPerformed

    private void onButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_onButtonActionPerformed
        // TODO add your handling code here:
        playerCount = 1;
        onButton.setEnabled(false);
        offButton.setEnabled(true);
    }//GEN-LAST:event_onButtonActionPerformed

    private void offButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_offButtonActionPerformed
        // TODO add your handling code here:
        playerCount = 0;
        offButton.setEnabled(false);
        onButton.setEnabled(true);
    }//GEN-LAST:event_offButtonActionPerformed

    public static synchronized void playSound(final String url) {
        new Thread(new Runnable() {
            // The wrapper thread is unnecessary, unless it blocks on the
            // Clip finishing; see comments.
            public void run() {
                try {
                    Clip clip = AudioSystem.getClip();
                    AudioInputStream inputStream = AudioSystem.getAudioInputStream(
                            //"/MainPackage/audioFile.wav"
                            Main.class.getResourceAsStream(url));
                    clip.open(inputStream);
                    clip.start();
                } catch (Exception e) {
                    System.err.println(e.getMessage());
                }
            }
        }).start();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(bjFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(bjFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(bjFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(bjFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new bjFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton checkWinnerButton;
    private javax.swing.JButton dealButton;
    private javax.swing.JLabel house1Label;
    private javax.swing.JLabel house2Label;
    private javax.swing.JLabel house3Label;
    private javax.swing.JLabel house4Label;
    private javax.swing.JLabel house5Label;
    private javax.swing.JLabel houseLabel;
    private javax.swing.JPanel housePanel;
    private javax.swing.JLabel houseSumField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton offButton;
    private javax.swing.JButton onButton;
    private javax.swing.JLabel one1Label;
    private javax.swing.JLabel one2Label;
    private javax.swing.JLabel one3Label;
    private javax.swing.JLabel one4Label;
    private javax.swing.JLabel one5Label;
    private javax.swing.JButton oneHitButton;
    private javax.swing.JLabel oneLabel;
    private javax.swing.JPanel onePanel;
    private javax.swing.JButton oneStandButton;
    private javax.swing.JLabel oneSumField;
    private javax.swing.JLabel oneSumLabel;
    private javax.swing.JLabel two1Label;
    private javax.swing.JLabel two2Label;
    private javax.swing.JLabel two3Label;
    private javax.swing.JLabel two4Label;
    private javax.swing.JLabel two5Label;
    private javax.swing.JButton twoHitButton;
    private javax.swing.JLabel twoLabel;
    private javax.swing.JPanel twoPanel;
    private javax.swing.JButton twoStandButton;
    private javax.swing.JLabel twoSumField;
    private javax.swing.JLabel twoSumLabel;
    // End of variables declaration//GEN-END:variables
}
