/**
 * Course: CS341 Data Structures
 * Date: April 2018
 * Assignment: CS341_FinalProject
 * Authors: Trevor Conway, Tristin Harvell, Travis Kruse, Johnny Tran
 */
package MainPackage;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import javax.swing.ImageIcon;

public class Deck implements DeckInterface {

    public Queue<Card> deckOfCards = new LinkedList<>();

    @Override
    public Queue<Card> makeDeck(Queue<Card> deckOfCards) {
        for (Card.Suit suit : Card.Suit.values()) {
            for (Card.Value value : Card.Value.values()) {
                deckOfCards.add(new Card(value, suit, null));
            }
        }
        for (int i = 0; i < deckOfCards.size(); i++) {
            Card temp = deckOfCards.remove();
            String temp2 = "/cards/" + temp.toString() + ".jpg";
            ImageIcon image;
            image = new ImageIcon(getClass().getResource(temp2));
            temp.setCardImage(image);
            deckOfCards.add(temp);
        }
        return deckOfCards;
    }

    public Deck() {
        deckOfCards = makeDeck(deckOfCards);
    }

    @Override
    public Queue<Card> getDeckOfCards() {
        return deckOfCards;
    }

    @Override
    public void setDeckOfCards(Queue<Card> deckOfCards) {
        this.deckOfCards = deckOfCards;
    }

    @Override
    public String toString() {
        return "Deck of cards: " + deckOfCards;
    }

    @Override
    public void shuffleDeck() {
        Collections.shuffle((List<Card>) deckOfCards);
    }

    @Override
    public void moveToBottom(Card newBottom) {
        deckOfCards.add(newBottom);
    }

    @Override
    public Card draw() {
        return deckOfCards.remove();
    }
}
