/**
 * Course: CS341 Data Structures
 * Date: April 2018
 * Assignment: CS341_FinalProject
 * Authors: Trevor Conway, Tristin Harvell, Travis Kruse, Johnny Tran
 */
package MainPackage;

import java.io.Serializable;

public class Player implements Serializable, PlayerInterface {

    //data members
    private String username = "";
    private int funds = 0;

    //blackjack stats
    private int bjWins = 0;
    private int bjLosses = 0;

    //memory match stats
    private int mmEasySolves = 0;
    private int mmMediumSolves = 0;
    private int mmHardSolves = 0;

    //simon says stats
    private int ssHighest = 0;

    //slapjack stats
    private int sjWins = 0;
    private int sjLosses = 0;

    public Player() {
    }

    public Player(String username, int funds) {
        this.username = username;
        this.funds = funds;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public int getFunds() {
        return funds;
    }

    @Override
    public void setFunds(int funds) {
        this.funds = funds;
    }

    @Override
    public String toString() {
        return username + ": $" + funds;
    }

    @Override
    public String getAllStats() {

        return "\n-------BLACKJACK--------------"
                + "\nWins: " + bjWins
                + "\nLosses: " + bjLosses
                + "\n-------MEMORY MATCH-----------"
                + "\nEasy Solves: " + mmEasySolves
                + "\nMedium Solves: " + mmMediumSolves
                + "\nHard Solves: " + mmHardSolves
                + "\n-------SIMON SAYS-------------"
                + "\nHigh Score: " + ssHighest
                + "\n-------SLAPJACK---------------"
                + "\nWins: " + sjWins
                + "\nLosses: " + sjLosses;
    }

    @Override
    public int getBjWins() {
        return bjWins;
    }

    @Override
    public void setBjWins(int num) {
        this.bjWins = num;
    }

    @Override
    public int getBjLosses() {
        return bjLosses;
    }

    @Override
    public void setBjLosses(int num) {
        this.bjLosses = num;
    }

    @Override
    public int getMmEasySolves() {
        return mmEasySolves;
    }

    @Override
    public void setMmEasySolves(int num) {
        this.mmEasySolves = num;
    }

    @Override
    public int getMmMediumSolves() {
        return mmMediumSolves;
    }

    @Override
    public void setMmMediumSolves(int num) {
        this.mmMediumSolves = num;
    }

    @Override
    public int getMmHardSolves() {
        return mmHardSolves;
    }

    @Override
    public void setMmHardSolves(int num) {
        this.mmHardSolves = num;
    }

    @Override
    public int getSsHighest() {
        return ssHighest;
    }

    @Override
    public void setSsHighest(int ssHighest) {
        this.ssHighest = ssHighest;
    }

    @Override
    public int getSjWins() {
        return sjWins;
    }

    @Override
    public void setSjWins(int num) {
        this.sjWins = num;
    }

    @Override
    public int getSjLosses() {
        return sjLosses;
    }

    @Override
    public void setSjLosses(int num) {
        this.sjLosses = num;
    }

    @Override
    public void resetAllStats() {
        this.sjLosses = 0;
        this.bjLosses = 0;
        this.bjWins = 0;
        this.mmEasySolves = 0;
        this.mmHardSolves = 0;
        this.mmMediumSolves = 0;
        this.sjWins = 0;
        this.ssHighest = 0;
    }
}
