/**
 * Course: CS341 Data Structures
 * Date: April 2018
 * Assignment: CS341_FinalProject
 * Authors: Trevor Conway, Tristin Harvell, Travis Kruse, Johnny Tran
 */
package GamePackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SimonSays implements SimonSaysInterface {

    List<Integer> order = new ArrayList<>();

    @Override
    public void addOrder() {
        Random rand = new Random();

        int n = rand.nextInt(3);
        order.add(order.size(), n);
    }

    @Override
    public int size() {
        return order.size();
    }

    @Override
    public boolean isMatch(List<Integer> inputOrder) {
        return inputOrder.equals(order);
    }

    @Override
    public List<Integer> play() {
        return order;
    }
}
