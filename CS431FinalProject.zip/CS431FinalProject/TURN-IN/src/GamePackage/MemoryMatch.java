/**
 * Course: CS341 Data Structures
 * Date: April 2018
 * Assignment: CS341_FinalProject
 * Authors: Trevor Conway, Tristin Harvell, Travis Kruse, Johnny Tran
 */
package GamePackage;

import MainPackage.Deck;
import MainPackage.Card;
import java.util.ArrayList;
import java.util.List;

public class MemoryMatch implements MemoryMatchInterface {

    //initialize lists and instantiate deck
    List<Card> original = new ArrayList<>();
    List<Card> copy = new ArrayList<>();
    Deck mmDeck = new Deck();

    //initialize difficulty 
    String difficulty;

    @Override
    public List<Card> getCards() {
        return original;
    }

    @Override
    public void generateMemoryMatch(String difficulty) {

        switch (difficulty) {
            case "easy":
                easyMode();
                break;
            case "medium":
                mediumMode();
                break;
            case "hard":
                hardMode();
                break;
        }
    }

    /**
     * easy Mode
     *
     * @require Require difficulty to be set
     * @ensure Easy game mode will be generated
     *
     */
    public void easyMode() {
        original.clear();
        copy.clear();

        mmDeck.shuffleDeck();

        original.add(mmDeck.draw());
        original.add(mmDeck.draw());

        copy = original;

        original.add(copy.get(0));
        original.add(copy.get(1));
    }

    /**
     * medium Mode
     *
     * @require Require difficulty to be set
     * @ensure Medium game mode will be generated
     *
     */
    public void mediumMode() {
        original.clear();
        copy.clear();

        mmDeck.shuffleDeck();

        original.add(mmDeck.draw());
        original.add(mmDeck.draw());
        original.add(mmDeck.draw());

        copy = original;

        original.add(copy.get(0));
        original.add(copy.get(1));
        original.add(copy.get(2));
    }

    /**
     * hard Mode
     *
     * @require Require difficulty to be set
     * @ensure Hard game mode will be generated
     *
     */
    public void hardMode() {
        original.clear();
        copy.clear();

        mmDeck.shuffleDeck();

        original.add(mmDeck.draw());
        original.add(mmDeck.draw());
        original.add(mmDeck.draw());
        original.add(mmDeck.draw());

        copy = original;

        original.add(copy.get(0));
        original.add(copy.get(1));
        original.add(copy.get(2));
        original.add(copy.get(3));
    }

    @Override
    public boolean isMatch(Card cardOne, Card cardTwo) {
        if (cardOne.getSuit().equals(cardTwo.getSuit())) {
            if (cardOne.getValue().equals(cardTwo.getValue())) {
                return true;
            }
        }
        return false;
    }
}
